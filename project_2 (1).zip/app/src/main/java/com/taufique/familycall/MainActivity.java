package com.taufique.familycall;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

/**
 * Home screen = assets/home.html (name, family code, big Join button).
 * The call itself = a Jitsi Meet room opened in the same WebView.
 */
public class MainActivity extends Activity {

    private static final String HOME = "file:///android_asset/home.html";
    private static final int REQ_MEDIA = 42;

    private WebView webView;
    private String pendingCallUrl = null;
    private String allowedHost = "meet.ffmuc.net";
    private boolean inCall = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        // Present as normal mobile Chrome (drop the "wv" WebView marker) so the
        // meeting page treats us as a supported browser.
        s.setUserAgentString(s.getUserAgentString().replace("; wv)", ")"));

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                // The meeting page asks for camera + microphone: grant what Android allowed us.
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                String host = uri.getHost();
                if ("file".equals(scheme)) return false;
                if (host != null && host.equalsIgnoreCase(allowedHost)) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                inCall = url != null && !url.startsWith("file:");
                setCallMode(inCall);
            }
        });

        webView.loadUrl(HOME);
    }

    private void setCallMode(boolean on) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (on) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            setVolumeControlStream(AudioManager.STREAM_VOICE_CALL);
            if (am != null) {
                am.setMode(AudioManager.MODE_IN_COMMUNICATION);
                am.setSpeakerphoneOn(true);
            }
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            setVolumeControlStream(AudioManager.USE_DEFAULT_STREAM_TYPE);
            if (am != null) {
                am.setSpeakerphoneOn(false);
                am.setMode(AudioManager.MODE_NORMAL);
            }
        }
    }

    private boolean hasMediaPermissions() {
        return checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void startCall(String url) {
        if (hasMediaPermissions()) {
            webView.loadUrl(url);
        } else {
            pendingCallUrl = url;
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, REQ_MEDIA);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQ_MEDIA) return;
        if (pendingCallUrl != null) {
            if (!hasMediaPermissions()) {
                Toast.makeText(this, "Camera/microphone access was not allowed. Turn it on in Settings > Apps > Alam Family > Permissions.", Toast.LENGTH_LONG).show();
            }
            webView.loadUrl(pendingCallUrl); // join anyway; works without audio/video if denied
            pendingCallUrl = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (inCall) {
            leaveCall();
        } else {
            super.onBackPressed();
        }
    }

    private void leaveCall() {
        webView.loadUrl("about:blank");   // stops camera + mic immediately
        webView.loadUrl(HOME);
        inCall = false;
        setCallMode(false);
        Toast.makeText(this, "You left the call", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        setCallMode(false);
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    /** Called from home.html */
    private class Bridge {
        @JavascriptInterface
        public void join(final String url, final String host) {
            runOnUiThread(() -> {
                if (host != null && !host.isEmpty()) allowedHost = host;
                startCall(url);
            });
        }

        @JavascriptInterface
        public void share(final String text) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(send, "Send to family"));
            });
        }
    }
}
